#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
esp_interface.py — versione definitiva (queue-based, 2025-11-03)
----------------------------------------------------------------
✅ Un solo lettore seriale (no conflitti): _reader() riempie una coda
✅ send_command() NON legge più dalla seriale: attende righe dalla coda
✅ Timeout esteso automatico per HOME/ZERO
✅ Auto-ripristino in caso di disconnessione reale
✅ Proxy a livello di modulo (connect/status/list_ports, ecc.)
"""

import serial, serial.tools.list_ports, threading, time, re
from collections import deque
from PyQt6.QtCore import QObject, pyqtSignal

class ESPInterface(QObject):
    sig_data = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.port = None
        self.baud = 115200
        self.ser = None

        # Stato thread/lock
        self.alive = False
        self.thread = None
        self.lock = threading.Lock()

        # Coda di righe ricevute (solo _reader la riempie)
        self.rx_queue = deque(maxlen=500)
        self.rx_event = threading.Event()
        self.queue_lock = threading.Lock()

    # -------------------- Porte --------------------
    def scan_ports(self):
        return [p.device for p in serial.tools.list_ports.comports()]

    list_ports = scan_ports  # alias retrocompatibile

    # -------------------- Connessione --------------------
    def connect(self, port: str, baud: int = 115200):
        if self.ser and self.ser.is_open:
            msg = f"[WARN] ESP già connesso su {self.port} @ {self.baud}"
            print(msg)
            return msg
        self.port, self.baud = port, baud
        try:
            self.ser = serial.Serial(port, baud, timeout=0.05)
            self._reset_queue()
            self.alive = True
            self.thread = threading.Thread(target=self._reader, daemon=True)
            self.thread.start()
            msg = f"[ESP CONNECTED] {port} @ {baud}"
            print(msg)
            return msg
        except Exception as e:
            msg = f"[ERR CONNECT] {e}"
            print(msg)
            return msg

    def disconnect(self):
        self.alive = False
        time.sleep(0.1)
        if self.ser and self.ser.is_open:
            try:
                self.ser.close()
            except:
                pass
        self.ser = None
        self._reset_queue()
        return "[ESP DISCONNECTED]"

    def _reset_queue(self):
        with self.queue_lock:
            self.rx_queue.clear()
        self.rx_event.clear()

    # -------------------- Invio comandi (via coda) --------------------
    def send_command(self, cmd: str, timeout: float = 0.4):
        """Invia cmd, poi attende nella coda la prima riga 'significativa' entro timeout."""
        if not self.ser or not self.ser.is_open:
            return "[ERR SEND] seriale non connessa"

        # Timeout esteso per comandi lunghi
        cmd_upper = cmd.strip().upper()
        if cmd_upper in ("HOME", "ZERO"):
            timeout = 15.0

        try:
            # invio atomico
            with self.lock:
                # non svuoto l'input buffer della seriale: _reader gestisce tutto
                self.ser.write((cmd.strip() + "\n").encode())
                self.ser.flush()

            # attendo risposte nella coda
            t0 = time.time()
            last_txt = ""
            expected_any = [b"OK", b"STATUS", b"POS", b"STOP", b"[WARN]", b"[ERR]"]
            if cmd_upper == "HOME":
                expected_any += [b"[HOME]"]
            if cmd_upper == "ZERO":
                expected_any += [b"[SYSTEM]"]

            while time.time() - t0 < timeout:
                # attendo evento con piccolo timeout
                remaining = max(0.01, timeout - (time.time() - t0))
                self.rx_event.wait(min(0.1, remaining))

                # scarico tutto ciò che c'è in coda
                lines = []
                with self.queue_lock:
                    while self.rx_queue:
                        lines.append(self.rx_queue.popleft())
                    if not self.rx_queue:
                        self.rx_event.clear()

                # analizzo le nuove righe
                for txt in lines:
                    last_txt = txt
                    bt = txt.encode()
                    if any(k in bt for k in expected_any):
                        # righe 'chiave' trovate → ritorno subito
                        self.sig_data.emit(txt)
                        return txt

                # se non ho trovato nulla di 'chiave', continuo ad attendere
            # timeout: ritorno l'ultima riga vista (se presente) o warning
            return last_txt if last_txt else "[WARN] Nessuna risposta"

        except Exception as e:
            # Auto-ripristino solo in caso di errori I/O reali
            if "device reports readiness" in str(e) or "Input/output" in str(e):
                print("[WARN] Porta seriale disconnessa o contesa, ripristino...")
                try:
                    self.disconnect()
                    time.sleep(0.5)
                    if self.port:
                        self.connect(self.port, self.baud)
                        return "[WARN] Porta seriale ripristinata"
                except Exception as ee:
                    return f"[ERR RIPRISTINO] {ee}"
            return f"[ERR SEND] {e}"

    # -------------------- Lettura (unico punto di I/O) --------------------
    def _reader(self):
        """Unico thread che legge la seriale, smista in coda ed emette segnali."""
        buf = b""
        while self.alive:
            try:
                if not self.ser or not self.ser.is_open:
                    time.sleep(0.2)
                    continue

                data = self.ser.read(128)
                if data:
                    buf += data
                    while b"\n" in buf:
                        line, buf = buf.split(b"\n", 1)
                        txt = line.decode(errors="ignore").strip()
                        if not txt:
                            continue
                        # metto in coda e sveglio eventuali attese
                        with self.queue_lock:
                            self.rx_queue.append(txt)
                            self.rx_event.set()
                        # inoltro alla GUI
                        self._process_line(txt)
                else:
                    time.sleep(0.02)
            except Exception as e:
                # non interrompo, segnalo e riprovo
                with self.queue_lock:
                    self.rx_queue.append(f"[ERR READER] {e}")
                    self.rx_event.set()
                time.sleep(0.3)

    def _process_line(self, txt: str):
        """Inoltra alla GUI le righe utili (senza filtrare eccessivamente)."""
        # Per semplicità inoltro tutto quello che può essere informativo:
        if txt.startswith(("POS ", "STATUS", "[", "OK", "PAN:", "TILT:")):
            self.sig_data.emit(txt)

    # -------------------- Utilità --------------------
    def is_connected(self):
        return self.ser is not None and self.ser.is_open

    def status(self):
        return self.send_command("STATUS")

# ===================== Istanza globale + Proxy =====================

try:
    esp = ESPInterface()
    print("[INIT] ESPInterface autoinizializzato (safe import)")
except Exception as e:
    esp = None
    print(f"[WARN] ESPInterface non inizializzato: {e}")

def list_ports():
    return esp.list_ports() if esp else []

def connect(port, baud=115200):
    if esp and esp.is_connected():
        print("[WARN] ESP già connesso, uso connessione esistente")
        return "[ESP ALREADY CONNECTED]"
    return esp.connect(port, baud) if esp else "[ERR] ESP non inizializzato"

def disconnect():
    return esp.disconnect() if esp else "[ERR] ESP non inizializzato"

def send_command(cmd, timeout=0.4):
    return esp.send_command(cmd, timeout) if esp else "[ERR] ESP non inizializzato"

def is_connected():
    return esp.is_connected() if esp else False

def status():
    return esp.status() if esp else "[ERR] ESP non inizializzato"
