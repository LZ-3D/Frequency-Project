#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys, json, serial, serial.tools.list_ports
from pathlib import Path
from datetime import datetime
from PyQt6.QtCore import Qt, QTimer, QSize, QRect, QThread, pyqtSignal, QObject
from PyQt6.QtGui import QFont, QColor, QIcon, QPainter, QBrush, QPen
from PyQt6.QtWidgets import (
    QWidget, QLabel, QPushButton, QComboBox, QScrollArea,
    QVBoxLayout, QHBoxLayout, QTextEdit, QFrame, QColorDialog,
    QGraphicsDropShadowEffect
)
from bleak import BleakScanner
import esp_interface as esp   # ✅ interfaccia seriale ESP32 thread-safe

# === Percorsi ================================================================
DIR_ICONE   = Path("/home/loki/Documents/Frequency/icone/")
CONFIG_FILE = Path("/home/loki/Documents/Frequency/config.json")

# === Colori ================================================================
BG_DARK   = "#0b1a0d"
NEON      = "#22ff77"
NEON_SOFT = "#17cc5c"
COLOR_OPTIONS = {
    "Verde radar": "#22ff77",
    "Verde chiaro": "#77ff99",
    "Bianco": "#ffffff",
    "Giallo": "#ffff55",
    "Rosso allarme": "#ff4444"
}
BAUDS = ["9600","19200","38400","57600","115200"]

# === QSS ====================================================================
def generate_qss(font_color="#22ff77", font_name="Orbitron"):
    return f"""
    QWidget {{
        background-color: {BG_DARK};
        color: {font_color};
        font-family: "{font_name}", "Aldrich", "DejaVu Sans Mono";
    }}
    QLabel#clock {{
        background-color: rgba(0,0,0,0.25);
        border: 2px solid {NEON_SOFT};
        border-radius: 8px;
        padding: 6px 20px;
        font-size: 24px;
        font-weight: 700;
        min-height: 48px;
        color: {font_color};
    }}
    QPushButton {{
        background-color: {BG_DARK};
        border: 3px solid {NEON_SOFT};
        color: {font_color};
        padding: 6px 12px;
        border-radius: 8px;
    }}
    QPushButton:hover {{
        border: 3px solid {font_color};
    }}
    QPushButton#round {{
        border-radius: 30px;
        min-width: 60px;
        min-height: 60px;
    }}
    QComboBox {{
        background-color: #000;
        color: {font_color};
        border: 2px solid {NEON_SOFT};
        padding: 4px;
        font-size: 16px;
    }}
    QTextEdit {{
        background-color: #000;
        color: {font_color};
        border: 2px solid {NEON_SOFT};
        font-family: monospace;
        font-size: 14px;
    }}
    QToolTip {{
        background-color: rgba(0, 30, 0, 0.9);
        color: {font_color};
        border: 2px solid {NEON_SOFT};
        font-family: "{font_name}";
        font-size: 14px;
        padding: 6px 10px;
        border-radius: 6px;
    }}
    """

# === Utility ================================================================
def list_serial_ports():
    ports = [p.device for p in serial.tools.list_ports.comports()]
    return ports if ports else ["Nessuna porta"]

def load_config():
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except:
            pass
    return {"esp_com":"/dev/ttyUSB0","esp_baud":"115200",
            "font":"Orbitron","font_color":"#22ff77",
            "font_color_name":"Verde radar"}

def save_config(cfg):
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))

def apply_press_glow(button):
    def on_pressed():
        glow = QGraphicsDropShadowEffect()
        glow.setOffset(0,0)
        glow.setBlurRadius(45)
        glow.setColor(QColor(NEON))
        button.setGraphicsEffect(glow)
    def on_released():
        button.setGraphicsEffect(None)
    button.pressed.connect(on_pressed)
    button.released.connect(on_released)

# === Toggle switch ==========================================================
class ToggleSwitch(QPushButton):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setMinimumSize(60, 30)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setStyleSheet("background: transparent; border: none;")
    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHints(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(2,2,-2,-2)
        bg = QColor(30,60,40) if not self.isChecked() else QColor(34,255,119)
        p.setBrush(QBrush(bg)); p.setPen(QPen(QColor("#17cc5c"),2))
        p.drawRoundedRect(rect, rect.height()/2, rect.height()/2)
        knob_d = rect.height()-6
        x = rect.left()+3 if not self.isChecked() else rect.right()-knob_d-3
        p.setBrush(QBrush(QColor("#0b1a0d")))
        p.drawEllipse(QRect(int(x),int(rect.top()+3),int(knob_d),int(knob_d)))

# === Worker thread connessione ESP ==========================================
class EspConnectWorker(QObject):
    done = pyqtSignal(str)
    def __init__(self, port, baud):
        super().__init__()
        self.port, self.baud = port, baud
    def run(self):
        try:
            msg = esp.connect(self.port, self.baud)
            if esp.is_connected():
                # FIX: rimosso doppio PING, solo STATUS
                status = esp.status()
                msg += f"\n{status or '[STATUS] (vuoto)'}"
            else:
                msg += "\n[ESP] Connessione fallita ❌"
        except Exception as e:
            msg = f"[ERRORE] {e}"
        self.done.emit(msg)

# === Pagina Impostazioni =====================================================
class SettingsPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.config = load_config()
        self.setStyleSheet(generate_qss(self.config["font_color"], self.config["font"]))

        outer = QVBoxLayout(self)
        frame = QFrame()
        frame.setStyleSheet(f"border:3px solid {NEON_SOFT}; border-radius:10px; background-color:{BG_DARK};")
        f = QVBoxLayout(frame); f.setContentsMargins(10,10,10,10)

        # === Barra superiore =================================================
        top = QHBoxLayout()
        btn_home = QPushButton(); btn_home.setObjectName("round")
        btn_home.setIcon(QIcon(str(DIR_ICONE/"icona_home.png"))); btn_home.setIconSize(QSize(36,36))
        btn_home.setToolTip("Torna alla schermata Home")
        btn_home.clicked.connect(self._go_home_action)
        apply_press_glow(btn_home)

        self.clock = QLabel("--:--:--"); self.clock.setObjectName("clock")
        self.clock.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.clock.setFixedHeight(52)
        self.clock.setFont(QFont(self.config["font"],22,QFont.Weight.Bold))

        btn_exit = QPushButton(); btn_exit.setObjectName("round")
        btn_exit.setIcon(QIcon(str(DIR_ICONE/"icona_exit.png"))); btn_exit.setIconSize(QSize(36,36))
        btn_exit.setToolTip("Chiudi programma")
        btn_exit.clicked.connect(lambda: sys.exit(0))
        apply_press_glow(btn_exit)

        top.addWidget(btn_home); top.addStretch(); top.addWidget(self.clock)
        top.addStretch(); top.addWidget(btn_exit)
        f.addLayout(top)
        line = QFrame(); line.setFixedHeight(2); line.setStyleSheet(f"background:{NEON_SOFT};")
        f.addWidget(line)

        # === Area scrollabile ================================================
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        content = QWidget(); scroll.setWidget(content)
        inner = QVBoxLayout(content); inner.setContentsMargins(20,20,20,20); inner.setSpacing(25)

        inner.addWidget(self.section_motori())
        inner.addWidget(self.section_bluetooth())
        inner.addWidget(self.section_fpv())
        inner.addWidget(self.section_radar())
        inner.addWidget(self.section_font())

        f.addWidget(scroll)
        outer.addWidget(frame)

        # === Orologio ========================================================
        self._t = QTimer(self)
        self._t.timeout.connect(lambda: self.clock.setText(datetime.now().strftime("%H:%M:%S")))
        self._t.start(1000)

    # === SEZIONI =============================================================
    def section_motori(self):
        frame = self.make_frame("MOTORI — Controllo ESP")
        v = frame.layout()

        r1 = QHBoxLayout(); r1.addWidget(QLabel("Porta COM:"))
        self.cmb_com_esp = QComboBox()
        ports = esp.list_ports()
        self.cmb_com_esp.addItems(ports)
        self.cmb_com_esp.setCurrentText(self.config.get("esp_com", ports[0] if ports else ""))
        r1.addWidget(self.cmb_com_esp); v.addLayout(r1)

        r2 = QHBoxLayout(); r2.addWidget(QLabel("Baud Rate:"))
        self.cmb_baud_esp = QComboBox(); self.cmb_baud_esp.addItems(BAUDS)
        self.cmb_baud_esp.setCurrentText(self.config.get("esp_baud","115200"))
        r2.addWidget(self.cmb_baud_esp); v.addLayout(r2)

        b = QPushButton("Connetti ESP")
        apply_press_glow(b)
        b.clicked.connect(self.connect_esp)
        v.addWidget(b)

        self.txt_esp = QTextEdit()
        self.txt_esp.setFixedHeight(120)
        v.addWidget(self.txt_esp)
        return frame

    def connect_esp(self):
        port = self.cmb_com_esp.currentText()
        baud = int(self.cmb_baud_esp.currentText())
        self._append_log(self.txt_esp, f"[ESP] Connessione a {port} @ {baud} ...")

        # Thread non bloccante
        self._esp_thread = QThread(self)
        self._esp_worker = EspConnectWorker(port, baud)
        self._esp_worker.moveToThread(self._esp_thread)
        self._esp_thread.started.connect(self._esp_worker.run)
        self._esp_worker.done.connect(lambda m: self._append_log(self.txt_esp, m))
        self._esp_worker.done.connect(self._esp_thread.quit)
        self._esp_thread.start()

    # === Sezioni supplementari ===============================================
    def section_bluetooth(self):
        frame = self.make_frame("TELEMETRIA — Modulo mLRS Bluetooth")
        v = frame.layout()
        h = QHBoxLayout()
        self.bt_switch = ToggleSwitch()
        self.bt_switch.setChecked(self.config.get("bluetooth_enabled", False))
        h.addWidget(QLabel("Stato:")); h.addWidget(self.bt_switch); h.addStretch()
        v.addLayout(h)

        btn_scan = QPushButton("Scansiona dispositivi"); apply_press_glow(btn_scan)
        btn_scan.clicked.connect(self._scan_bt_thread)
        v.addWidget(btn_scan)
        self.cmb_bt_devices = QComboBox(); v.addWidget(self.cmb_bt_devices)
        return frame

    # === Scansione BLE (thread separato, nessun asyncio) ====================
    def _scan_bt_thread(self):
        self.cmb_bt_devices.clear()
        self.cmb_bt_devices.addItem("Scansione in corso...")

        def run_scan():
            import asyncio
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            devices = loop.run_until_complete(BleakScanner.discover(timeout=4.0))
            loop.close()
            return [f"{d.name or 'Sconosciuto'} ({d.address})" for d in devices]

        import threading
        def work():
            try:
                devs = run_scan()
            except Exception as e:
                devs = [f"Errore scansione: {e}"]
            self.cmb_bt_devices.clear()
            self.cmb_bt_devices.addItems(devs if devs else ["Nessun dispositivo trovato"])

        threading.Thread(target=work, daemon=True).start()

    def section_fpv(self):
        frame = self.make_frame("VIDEO — Interfaccia Walksnail")
        v = frame.layout()
        v.addWidget(QLabel("Porta USB Video: /dev/video0"))
        v.addWidget(QLabel("Risoluzione: 1280x720 @ 60fps"))
        v.addWidget(QLabel("Compressione: H.264"))
        return frame

    def section_radar(self):
        frame = self.make_frame("RADAR — Dati Telemetrici e Tracciamento")
        v = frame.layout()
        v.addWidget(QLabel("GPS Stazione: BN-180"))
        v.addWidget(QLabel("Aggiornamento: 10Hz"))
        v.addWidget(QLabel("Coordinate base memorizzate nel file config.json"))
        return frame

    def section_font(self):
        frame = self.make_frame("INTERFACCIA — Font e Colori")
        v = frame.layout()
        r1 = QHBoxLayout(); r1.addWidget(QLabel("Font:"))
        self.cmb_font = QComboBox()
        self.cmb_font.addItems(["Orbitron","Aldrich","DejaVu Sans Mono"])
        self.cmb_font.setCurrentText(self.config.get("font","Orbitron"))
        r1.addWidget(self.cmb_font); v.addLayout(r1)
        r2 = QHBoxLayout(); r2.addWidget(QLabel("Colore testo:"))
        self.cmb_color = QComboBox()
        self.cmb_color.addItems(COLOR_OPTIONS.keys())
        self.cmb_color.setCurrentText(self.config.get("font_color_name","Verde radar"))
        r2.addWidget(self.cmb_color)
        btn_pick = QPushButton("Personalizza...")
        btn_pick.clicked.connect(self.pick_color)
        r2.addWidget(btn_pick); v.addLayout(r2)
        btn_apply = QPushButton("Applica e Salva")
        btn_apply.clicked.connect(self.apply_font_settings)
        apply_press_glow(btn_apply); v.addWidget(btn_apply)
        return frame

    def pick_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.config["font_color"] = color.name()
            self.setStyleSheet(generate_qss(color.name(), self.config.get("font","Orbitron")))

    def apply_font_settings(self):
        self.config["font"] = self.cmb_font.currentText()
        cname = self.cmb_color.currentText()
        self.config["font_color_name"] = cname
        self.config["font_color"] = COLOR_OPTIONS[cname]
        save_config(self.config)
        self.setStyleSheet(generate_qss(self.config["font_color"], self.config["font"]))
        if hasattr(self.parent, "refresh_style_after_settings"):
            self.parent.refresh_style_after_settings()

    # === Helper =============================================================
    def make_frame(self, titolo):
        frame = QFrame()
        frame.setStyleSheet(f"border:2px solid {NEON_SOFT}; border-radius:8px;")
        v = QVBoxLayout(frame)
        lab = QLabel(titolo)
        lab.setFont(QFont("Orbitron", 18, QFont.Weight.Bold))
        v.addWidget(lab)
        return frame

    def _append_log(self, widget, msg):
        if widget:
            widget.append(msg)

    def _go_home_action(self):
        if hasattr(self.parent, "show_home"):
            self.parent.show_home()
