#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys, json
from pathlib import Path
from datetime import datetime
from PyQt6.QtCore import Qt, QTimer, QSize
from PyQt6.QtGui import QIcon, QFont, QColor, QPalette
from PyQt6.QtWidgets import QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QFrame, QGraphicsDropShadowEffect

DIR_ICONE = Path("/home/loki/Documents/Frequency/icone/")
CONFIG_FILE = Path("/home/loki/Documents/Frequency/config.json")

BG_DARK = "#0b1a0d"
NEON_SOFT = "#17cc5c"

def load_config():
    if CONFIG_FILE.exists():
        try: return json.loads(CONFIG_FILE.read_text())
        except: pass
    return {"font": "Orbitron", "font_color": "#22ff77"}

def generate_qss(font_color="#22ff77", font_name="Orbitron"):
    return f"""
    QWidget {{
        background-color: {BG_DARK};
        color: {font_color};
        font-family: "{font_name}", "Aldrich";
    }}
    QLabel#clock {{
        background-color: rgba(0,0,0,0.25);
        border: 2px solid {NEON_SOFT};
        border-radius: 8px;
        padding: 10px 22px;
        font-size: 26px;
        min-height: 60px;
        color: {font_color};
    }}
    QPushButton {{
        background-color: {BG_DARK};
        border: 3px solid {NEON_SOFT};
        color: {font_color};
    }}
    QPushButton:hover {{
        border: 3px solid {font_color};
    }}
    QPushButton#round {{
        border-radius: 30px;
        min-width: 60px;
        min-height: 60px;
    }}
    """

def apply_press_glow(button):
    def on_pressed():
        glow = QGraphicsDropShadowEffect()
        glow.setOffset(0, 0)
        glow.setBlurRadius(45)
        glow.setColor(QColor("#22ff77"))
        button.setGraphicsEffect(glow)
    def on_released():
        button.setGraphicsEffect(None)
    button.pressed.connect(on_pressed)
    button.released.connect(on_released)

class FPVPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent
        self.config = load_config()
        self.setStyleSheet(generate_qss(self.config["font_color"], self.config["font"]))

        outer = QVBoxLayout(self)
        frame = QFrame()
        frame.setStyleSheet(f"border: 3px solid {NEON_SOFT}; border-radius: 10px; background-color: {BG_DARK};")
        f = QVBoxLayout(frame)

        # Barra superiore
        top = QHBoxLayout()
        btn_home = QPushButton()
        btn_home.setObjectName("round")
        btn_home.setIcon(QIcon(str(DIR_ICONE / "icona_home.png")))
        btn_home.setIconSize(QSize(36, 36))
        btn_home.setToolTip("Torna alla Home")
        btn_home.clicked.connect(self._go_home)
        apply_press_glow(btn_home)

        self.clock = QLabel("--:--:--")
        self.clock.setObjectName("clock")
        self.clock.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.clock.setFixedHeight(60)
        self.clock.setFont(QFont(self.config["font"], 26))

        btn_exit = QPushButton()
        btn_exit.setObjectName("round")
        btn_exit.setIcon(QIcon(str(DIR_ICONE / "icona_exit.png")))
        btn_exit.setIconSize(QSize(36, 36))
        btn_exit.setToolTip("Chiudi programma")
        btn_exit.clicked.connect(lambda: sys.exit(0))
        apply_press_glow(btn_exit)

        top.addWidget(btn_home)
        top.addStretch()
        top.addWidget(self.clock)
        top.addStretch()
        top.addWidget(btn_exit)
        f.addLayout(top)

        title = QLabel("FPV — VIDEO IN")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont(self.config["font"], 38, QFont.Weight.Bold))
        f.addWidget(title)

        outer.addWidget(frame)
        self._t = QTimer(self)
        self._t.timeout.connect(lambda: self.clock.setText(datetime.now().strftime("%H:%M:%S")))
        self._t.start(1000)

    def _go_home(self):
        if hasattr(self.parent_window, "show_home"):
            self.parent_window.show_home()
