#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys, json, re, math, threading
from pathlib import Path
from datetime import datetime
from PyQt6.QtCore import Qt, QTimer, QSize, QThread, pyqtSignal, QObject, QEvent
from PyQt6.QtGui import QIcon, QColor, QFont, QPainter, QPen, QBrush, QTextCursor
from PyQt6.QtWidgets import (
    QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
    QFrame, QTextEdit, QGridLayout, QSlider, QGraphicsDropShadowEffect
)
import esp_interface as esp

# === Percorsi / colori =====================================================
DIR_ICONE   = Path("/home/loki/Documents/Frequency/icone/")
CONFIG_FILE = Path("/home/loki/Documents/Frequency/config.json")
LOG_FILE    = Path("/home/loki/Documents/Frequency/logs/manuale_log.txt")

BG_DARK   = "#0b1a0d"
NEON      = "#22ff77"
NEON_SOFT = "#17cc5c"

# === Limiti fisici (escursione reale) =====================================
PAN_MIN, PAN_MAX   = 0.0, 360.0
TILT_MIN, TILT_MAX = 0.0, 180.0

# === Micro calibrazione opzionale (mantieni 1.0 se l'ESP invia già gradi reali) ==
CAL_PAN  = 1.0     # es. 1.0185 se vuoi +1.85%
CAL_TILT = 1.0     # es. 1.0278 se vuoi +2.78%

# === UI ===================================================================
def generate_qss(font_color="#22ff77", font_name="Orbitron"):
    return f"""
    QWidget {{
        background-color:{BG_DARK};
        color:{font_color};
        font-family:"{font_name}","Aldrich","DejaVu Sans Mono";
    }}
    QLabel#clock {{
        background-color:rgba(0,0,0,0.22);
        border:2px solid {NEON_SOFT};
        border-radius:8px;
        padding:6px 22px;
        font-size:26px;font-weight:700;color:{font_color};
    }}
    QPushButton {{
        background-color:{BG_DARK};
        border:3px solid {NEON_SOFT};
        color:{font_color};
        padding:8px;border-radius:12px;
    }}
    QPushButton:hover {{border:3px solid {font_color};}}
    QPushButton[active="true"] {{ border-color:{font_color}; }}
    QTextEdit {{
        background-color:#000;color:{font_color};
        border:2px solid {NEON_SOFT};
        font-family:monospace;font-size:14px;
    }}
    QSlider::groove:horizontal {{ background:#012b12;height:8px;border-radius:4px; }}
    QSlider::handle:horizontal {{ background:{font_color};width:18px;height:18px;margin:-5px 0;border-radius:9px; }}
    """

def apply_press_glow(b):
    def on():
        glow=QGraphicsDropShadowEffect()
        glow.setOffset(0,0); glow.setBlurRadius(45); glow.setColor(QColor(NEON))
        b.setGraphicsEffect(glow)
    def off(): b.setGraphicsEffect(None)
    b.pressed.connect(on); b.released.connect(off)

def log_to_file(msg):
    try:
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")
    except: pass

# === Worker STATUS one-shot ===============================================
class StatusWorker(QThread):
    data = pyqtSignal(str)
    def run(self):
        try:
            if esp.is_connected():
                r = esp.send_command("STATUS", timeout=2)
                if r: self.data.emit(r)
        except Exception as e:
            self.data.emit(f"[ERR STATUS] {e}")

# === Gauge radar ==========================================================
class Gauge(QWidget):
    def __init__(self, title, col=NEON, span_min=0.0, span_max=360.0):
        super().__init__()
        self.title=title; self.col=QColor(col)
        self.val=0.0; self.sweep=0
        self.span_min, self.span_max = span_min, span_max
        self.t=QTimer(self); self.t.timeout.connect(self._anim); self.t.start(50)
    def _anim(self): self.sweep=(self.sweep+6)%360; self.update()
    def set_value(self,v):
        try: self.val=float(v)
        except: self.val=0.0
        self.val=max(self.span_min, min(self.span_max,self.val)); self.update()
    def paintEvent(self,e):
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w,h=self.width(),self.height(); r=min(w,h)/2.3; cx,cy=w/2.4,h/2
        p.setPen(QPen(QColor(NEON_SOFT),2)); p.setBrush(QBrush(QColor("#001100")))
        p.drawEllipse(int(cx-r),int(cy-r),int(2*r),int(2*r))
        for a in range(0,360,30):
            rad=math.radians(a-90)
            p.drawLine(int(cx+(r-10)*math.cos(rad)),int(cy+(r-10)*math.sin(rad)),
                       int(cx+r*math.cos(rad)),int(cy+r*math.sin(rad)))
        g=QColor(self.col); g.setAlpha(60)
        p.setBrush(QBrush(g)); p.setPen(Qt.PenStyle.NoPen)
        p.drawPie(int(cx-r),int(cy-r),int(2*r),int(2*r),int((self.sweep-25)*16),int(25*16))
        frac=(self.val-self.span_min)/(self.span_max-self.span_min) if self.span_max>self.span_min else 0
        rad=math.radians(frac*360-90)
        p.setPen(QPen(self.col,4))
        p.drawLine(int(cx),int(cy),int(cx+(r-20)*math.cos(rad)),int(cy+(r-20)*math.sin(rad)))
        p.setBrush(QBrush(self.col)); p.drawEllipse(int(cx-4),int(cy-4),8,8)
        p.setPen(self.col); p.setFont(QFont("Orbitron",16,QFont.Weight.Bold))
        p.drawText(int(cx+r+25),int(cy-15),200,30,Qt.AlignmentFlag.AlignLeft,self.title)
        p.setFont(QFont("Orbitron",20,QFont.Weight.Bold))
        p.drawText(int(cx+r+25),int(cy+18),200,40,Qt.AlignmentFlag.AlignLeft,f"{self.val:.1f}°"); p.end()

# === Pagina Manuale =======================================================
class ManualePage(QWidget):
    sig_log = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.cfg=self._cfg()
        self.setStyleSheet(generate_qss(self.cfg.get("font_color","#22ff77"),
                                        self.cfg.get("font","Orbitron")))

        # Stato
        self.pan, self.tilt = 180.0, 0.0
        self.step = 1.0
        self._tx_lock = threading.Lock()
        self._auto_scroll = True

        # Smooth hold (anti-saturazione): timer 200ms con rampa
        self.smooth_timer = QTimer(self); self.smooth_timer.timeout.connect(self._smooth_tick)
        self.smooth_active = False
        self.smooth_axis = None    # "PAN" | "TILT"
        self.smooth_sign = +1
        self.smooth_gain = 1.0     # rampa: 1.0 → 1.5 → 2.0 → ... → 5.0
        self.smooth_gain_max = 5.0
        self.smooth_period_ms = 200

        # UI
        self._build_ui()
        self.sig_log.connect(self._append_log)

        # Timers
        self.tclk=QTimer(self); self.tclk.timeout.connect(lambda:self.clock.setText(datetime.now().strftime("%H:%M:%S"))); self.tclk.start(1000)
        self.tled=QTimer(self); self.tled.timeout.connect(self._upd_led); self.tled.start(1500)

        # STATUS solo su richiesta, qui facciamo una sync iniziale one-shot
        QTimer.singleShot(300, self._safe_sync)

        # Thread STATUS gestito con riferimento per evitare “Destroyed while running”
        self.w_status=None

    # ------------------------ UI ------------------------------------------
    def _build_ui(self):
        lay=QVBoxLayout(self)
        frame=QFrame(); frame.setStyleSheet(f"border:3px solid {NEON_SOFT};border-radius:10px;background:{BG_DARK};")
        v=QVBoxLayout(frame); lay.addWidget(frame)

        # top bar
        top=QHBoxLayout()
        btn_home=QPushButton(); btn_home.setIcon(QIcon(str(DIR_ICONE/'icona_home.png'))); btn_home.setIconSize(QSize(36,36))
        btn_home.clicked.connect(self._go_home); apply_press_glow(btn_home)
        self.led=QLabel("●"); self.led.setFont(QFont("Orbitron",28,QFont.Weight.Bold)); self.led.setStyleSheet("color:#ff4444;")
        self.clock=QLabel("--:--:--"); self.clock.setObjectName("clock"); self.clock.setAlignment(Qt.AlignmentFlag.AlignCenter)
        btn_exit=QPushButton(); btn_exit.setIcon(QIcon(str(DIR_ICONE/'icona_exit.png'))); btn_exit.setIconSize(QSize(36,36))
        btn_exit.clicked.connect(lambda: sys.exit(0)); apply_press_glow(btn_exit)
        top.addWidget(btn_home); top.addStretch(); top.addWidget(self.led); top.addWidget(self.clock); top.addStretch(); top.addWidget(btn_exit)
        v.addLayout(top)

        sep=QFrame(); sep.setFixedHeight(2); sep.setStyleSheet(f"background:{NEON_SOFT};"); v.addWidget(sep)

        # Joystick
        joy=QFrame(); joy.setStyleSheet(f"border:2px solid {NEON_SOFT};border-radius:8px;"); grid=QGridLayout(joy); grid.setSpacing(16)
        def B(icon, cmd, tip):
            b=QPushButton(); b.setIcon(QIcon(str(DIR_ICONE/icon))); b.setIconSize(QSize(64,64)); b.setToolTip(tip); apply_press_glow(b)
            b.pressed.connect(lambda c=cmd: self._smooth_press(c))
            b.released.connect(self._smooth_release)
            b.clicked.connect(lambda _, c=cmd: self._move_click(c))
            return b
        self.btn_up=B("icona_su.png","TILT:+","Tilt su")
        self.btn_dn=B("icona_giu.png","TILT:-","Tilt giù")
        self.btn_lf=B("icona_sx.png","PAN:-","Pan sinistra")
        self.btn_rt=B("icona_dx.png","PAN:+","Pan destra")
        self.btn_zero=QPushButton("O"); self.btn_zero.setFont(QFont("Orbitron",32,QFont.Weight.Bold)); self.btn_zero.setToolTip("ZERO (PAN=180 / TILT=0)")
        self.btn_zero.clicked.connect(lambda: self._tx("ZERO")); apply_press_glow(self.btn_zero)
        grid.addWidget(self.btn_up,0,1); grid.addWidget(self.btn_lf,1,0); grid.addWidget(self.btn_zero,1,1); grid.addWidget(self.btn_rt,1,2); grid.addWidget(self.btn_dn,2,1)
        v.addWidget(joy)

        # Gauge
        gh=QHBoxLayout()
        self.gp=Gauge("PAN", span_min=PAN_MIN, span_max=PAN_MAX)
        self.gt=Gauge("TILT", span_min=TILT_MIN, span_max=TILT_MAX)
        gh.addWidget(self.gp); gh.addWidget(self.gt)
        v.addLayout(gh)

        # Step
        stepf=QFrame(); stepf.setStyleSheet(f"border:2px solid {NEON_SOFT};border-radius:8px;"); sh=QHBoxLayout(stepf)
        self._step_btns=[]
        for val in (1,5,10,25):
            b=QPushButton(f"{val}°"); apply_press_glow(b)
            b.clicked.connect(lambda _,x=val:self._set_step(float(x)))
            sh.addWidget(b); self._step_btns.append((b,float(val)))
        v.addWidget(stepf)

        # Motori / utilità
        tools=QHBoxLayout()
        self.btn_mpan=QPushButton("PAN ●"); self.btn_mtilt=QPushButton("TILT ●")
        for b in (self.btn_mpan,self.btn_mtilt): b.setFont(QFont("Orbitron",18,QFont.Weight.Bold)); apply_press_glow(b)
        self.btn_mpan.clicked.connect(self._toggle_motor_pan)
        self.btn_mtilt.clicked.connect(self._toggle_motor_tilt)
        self.btn_home=QPushButton("HOME"); apply_press_glow(self.btn_home); self.btn_home.clicked.connect(lambda:self._tx("HOME"))
        self.btn_status=QPushButton("STATUS"); apply_press_glow(self.btn_status); self.btn_status.clicked.connect(self._status_now)
        self.btn_clear=QPushButton("🧹 CLEAR LOG"); apply_press_glow(self.btn_clear); self.btn_clear.clicked.connect(lambda:self.txt.clear())
        tools.addWidget(self.btn_mpan); tools.addWidget(self.btn_mtilt); tools.addWidget(self.btn_home); tools.addWidget(self.btn_status); tools.addWidget(self.btn_clear)
        v.addLayout(tools)

        # Log
        self.txt=QTextEdit(); self.txt.setFixedHeight(240); v.addWidget(self.txt)
        self.txt.installEventFilter(self)
        self._set_step(1.0)

    # ------------------------ Event filter (auto-scroll freeze) ------------
    def eventFilter(self, obj: QObject, ev: QEvent):
        if obj is self.txt:
            if ev.type()==QEvent.Type.Enter: self._auto_scroll=False
            elif ev.type()==QEvent.Type.Leave: self._auto_scroll=True
        return super().eventFilter(obj,ev)

    # ------------------------ LED connessione ------------------------------
    def _upd_led(self):
        self.led.setStyleSheet("color:#22ff77;" if esp.is_connected() else "color:#ff4444;")

    # ------------------------ Step UI --------------------------------------
    def _set_step(self, val: float):
        self.step=float(val)
        for b,v in self._step_btns:
            b.setProperty("active","true" if abs(v-self.step)<1e-6 else "false")
            b.style().unpolish(b); b.style().polish(b)

    # ------------------------ Movimento fluido (hold) ----------------------
    def _smooth_press(self, cmd: str):
        self.smooth_axis = "TILT" if cmd.startswith("TILT") else "PAN"
        self.smooth_sign = +1 if "+" in cmd else -1
        self.smooth_gain = 1.0
        self.smooth_active = True
        self.smooth_timer.start(self.smooth_period_ms)

    def _smooth_release(self):
        if not self.smooth_active: return
        self.smooth_active = False
        self.smooth_timer.stop()
        # Se il firmware prevede STOP asse, abilita la prossima riga:
        # self._tx(f"STOP {self.smooth_axis}")

    def _smooth_tick(self):
        if not (self.smooth_active and self.smooth_axis): return
        # delta con rampa, ma a bassa frequenza per non saturare
        delta = self.step * self.smooth_gain
        self.smooth_gain = min(self.smooth_gain + 0.5, self.smooth_gain_max)

        # clamp rispetto ai limiti attuali
        cur = self.tilt if self.smooth_axis=="TILT" else self.pan
        nxt = cur + (delta if self.smooth_sign>0 else -delta)
        if self.smooth_axis=="TILT":
            if nxt < TILT_MIN: delta = max(0.0, cur - TILT_MIN)
            if nxt > TILT_MAX: delta = max(0.0, TILT_MAX - cur)
        else:
            if nxt < PAN_MIN:  delta = max(0.0, cur - PAN_MIN)
            if nxt > PAN_MAX:  delta = max(0.0, PAN_MAX - cur)
        if delta <= 0.001:
            self._smooth_release()
            return

        sign = "+" if self.smooth_sign>0 else "-"
        self._tx(f"MOVE {self.smooth_axis} {sign}{delta:.3f}")

    # ------------------------ Click singolo --------------------------------
    def _move_click(self, cmd: str):
        axis="TILT" if cmd.startswith("TILT") else "PAN"
        sign="+" if "+" in cmd else "-"
        self._tx(f"MOVE {axis} {sign}{self.step:.3f}")

    # ------------------------ Motori ---------------------------------------
    def _set_motor_led(self, btn: QPushButton, enabled: bool):
        color = "#ff4444" if enabled else "#22ff77"
        btn.setStyleSheet(f"QPushButton{{border:3px solid {NEON_SOFT}; color:{color};}}")
        btn.setProperty("enabled_state", enabled)

    def _toggle_motor_pan(self):
        en = not bool(self.btn_mpan.property("enabled_state"))
        self._tx("MOTOR_PAN_ON" if en else "MOTOR_PAN_OFF")
        self._set_motor_led(self.btn_mpan, en)

    def _toggle_motor_tilt(self):
        en = not bool(self.btn_mtilt.property("enabled_state"))
        self._tx("MOTOR_TILT_ON" if en else "MOTOR_TILT_OFF")
        self._set_motor_led(self.btn_mtilt, en)

    # ------------------------ STATUS / SYNC (no polling) -------------------
    def _status_now(self):
        try:
            if not esp.is_connected():
                self._connect_if_needed()
            if self.w_status and self.w_status.isRunning():
                self.w_status.quit(); self.w_status.wait(500)
            self.w_status = StatusWorker()
            self.w_status.data.connect(self._on_status_rx)
            self.w_status.finished.connect(lambda: setattr(self, "w_status", None))
            self.w_status.start()
        except Exception as e:
            self.sig_log.emit(f"[ERR STATUS_NOW] {e}")

    def _safe_sync(self):
        try: self._status_now()
        except Exception as e: self.sig_log.emit(f"[ERRORE SYNC INIT] {e}")

    def _connect_if_needed(self):
        if not esp.is_connected():
            cfg=self._cfg()
            self.sig_log.emit(esp.connect(cfg.get("esp_com","/dev/ttyUSB0"), int(cfg.get("esp_baud",115200))))

    def _on_status_rx(self, txt: str):
        self.sig_log.emit(txt)
        self._parse_status(txt)

    # ------------------------ Parsing STATUS -------------------------------
    def _parse_status(self, txt: str):
        try:
            p = re.findall(r"PAN\s*[:=]\s*([-+]?\d+\.?\d*)", txt)
            t = re.findall(r"TILT\s*[:=]\s*([-+]?\d+\.?\d*)", txt)
            if p: self.pan  = max(PAN_MIN,  min(PAN_MAX,  float(p[-1]) * CAL_PAN))
            if t: self.tilt = max(TILT_MIN, min(TILT_MAX, float(t[-1]) * CAL_TILT))
            self.gp.set_value(self.pan); self.gt.set_value(self.tilt)
        except: pass
        m = re.search(r"MOTORS.*PAN\s*:\s*(ON|OFF).*TILT\s*:\s*(ON|OFF)", txt, re.I)
        if m:
            self._set_motor_led(self.btn_mpan,  m.group(1).upper()=="ON")
            self._set_motor_led(self.btn_mtilt, m.group(2).upper()=="ON")

    # ------------------------ TX thread-safe -------------------------------
    def _tx(self, cmd: str):
        def run():
            try:
                with self._tx_lock:
                    r = esp.send_command(cmd)
                    if r:
                        self.sig_log.emit(f"[TX] {cmd}\n{r}")
                        self._parse_status(r)
            except Exception as e:
                self.sig_log.emit(f"[ERR] {e}")
        threading.Thread(target=run, daemon=True).start()

    # ------------------------ Log / Misc -----------------------------------
    def _append_log(self, msg: str):
        if not msg: return
        self.txt.append(msg)
        if self._auto_scroll: self.txt.moveCursor(QTextCursor.MoveOperation.End)
        log_to_file(msg)

    def closeEvent(self, e):
        try:
            if self.smooth_timer.isActive(): self.smooth_timer.stop()
            if self.w_status and self.w_status.isRunning():
                self.w_status.quit(); self.w_status.wait(500)
                self.w_status=None
        except Exception as ex:
            print(f"[CLOSE THREAD] {ex}")
        e.accept()

    def _go_home(self):
        w=self.parent()
        while w:
            if hasattr(w,"show_home"): w.show_home(); return
            w=w.parent()

    def _cfg(self):
        if CONFIG_FILE.exists():
            try: return json.loads(CONFIG_FILE.read_text())
            except: pass
        return {"font":"Orbitron","font_color":"#22ff77","esp_com":"/dev/ttyUSB0","esp_baud":"115200"}
