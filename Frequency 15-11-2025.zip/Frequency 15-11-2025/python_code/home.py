#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys, json
from pathlib import Path
from datetime import datetime
from PyQt6.QtCore import Qt, QTimer, QSize
from PyQt6.QtGui import QIcon, QFont, QColor, QPalette
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton,
    QVBoxLayout, QHBoxLayout, QGridLayout, QSizePolicy, QFrame,
    QStackedWidget, QGraphicsDropShadowEffect
)

# === Percorsi ================================================================
DIR_ICONE  = Path("/home/loki/Documents/Frequency/icone/")
DIR_CODE   = Path("/home/loki/Documents/Frequency/python_code/")
CONFIG_FILE = Path("/home/loki/Documents/Frequency/config.json")

# === Colori radar base =======================================================
BG_DARK = "#0b1a0d"
NEON_SOFT = "#17cc5c"

# === Lettura configurazione ==================================================
def load_config():
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except Exception:
            pass
    return {
        "font": "Orbitron",
        "font_color": "#22ff77",
        "font_color_name": "Verde radar"
    }

# === Stile dinamico ==========================================================
def generate_qss(font_color="#22ff77", font_name="Orbitron"):
    return f"""
    QWidget {{
        background-color: {BG_DARK};
        color: {font_color};
        font-family: "{font_name}", "Aldrich", "DejaVu Sans Mono";
    }}
    QLabel#clock {{
        background-color: rgba(0,0,0,0.25);
        border: 2px solid {NEON_SOFT};
        border-radius: 8px;
        padding: 10px 22px;
        font-size: 26px;
        font-weight: 700;
        min-height: 60px;
        color: {font_color};
    }}
    QPushButton {{
        background-color: {BG_DARK};
        border: 3px solid {NEON_SOFT};
        color: {font_color};
    }}
    QPushButton:hover {{
        border: 3px solid {font_color};
    }}
    QPushButton:pressed {{
        border: 3px solid {font_color};
    }}
    QPushButton#round {{
        border-radius: 30px;
        min-width: 60px;
        min-height: 60px;
    }}
    QToolTip {{
        background-color: rgba(0, 30, 0, 0.9);
        color: {font_color};
        border: 2px solid {NEON_SOFT};
        font-family: "{font_name}";
        font-size: 14px;
        padding: 6px 10px;
        border-radius: 6px;
    }}
    """

# === Effetto glow ============================================================
def apply_press_glow(button):
    def on_pressed():
        glow = QGraphicsDropShadowEffect()
        glow.setOffset(0, 0)
        glow.setBlurRadius(45)
        glow.setColor(QColor(button.palette().color(QPalette.ColorRole.WindowText)))
        button.setGraphicsEffect(glow)
    def on_released():
        button.setGraphicsEffect(None)
    button.pressed.connect(on_pressed)
    button.released.connect(on_released)

# === Pulsante radar ==========================================================
class TileButton(QWidget):
    def __init__(self, label, icon_path: Path, font_name, font_color):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setContentsMargins(5, 5, 5, 5)

        self.button = QPushButton()
        self.button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.button.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.button.setMinimumHeight(250)
        self.button.setStyleSheet(f"""
            QPushButton {{
                border: 3px solid {NEON_SOFT};
                color: {font_color};
                background-color: {BG_DARK};
                padding: 10px;
            }}
            QPushButton:hover {{
                border: 3px solid {font_color};
            }}
            QPushButton:pressed {{
                border: 3px solid {font_color};
                background-color: {BG_DARK};
            }}
        """)

        inner = QVBoxLayout()
        inner.setAlignment(Qt.AlignmentFlag.AlignCenter)
        inner.setContentsMargins(0, 0, 0, 0)
        inner.setSpacing(8)

        if icon_path.exists():
            icon_label = QLabel()
            icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            icon_label.setPixmap(QIcon(str(icon_path)).pixmap(110, 110))
            inner.addWidget(icon_label, alignment=Qt.AlignmentFlag.AlignCenter)

        text_label = QLabel("\n".join(label.split()))
        text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        text_label.setFont(QFont(font_name, 42, QFont.Weight.Bold))
        text_label.setStyleSheet(f"color: {font_color}; font-size: 42px; font-weight: bold;")
        inner.addWidget(text_label, alignment=Qt.AlignmentFlag.AlignCenter)

        self.button.setLayout(inner)
        layout.addWidget(self.button)
        apply_press_glow(self.button)

# === Finestra principale =====================================================
class HomeWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Frequency — Home")
        self.setMinimumSize(1800, 900)
        self.setWindowIcon(QIcon(str(DIR_ICONE / "icona_frequency.png")))

        self.config = load_config()
        self.setStyleSheet(generate_qss(self.config["font_color"], self.config["font"]))

        palette = self.palette()
        palette.setColor(QPalette.ColorRole.Window, QColor(BG_DARK))
        self.setPalette(palette)

        # Stack per le pagine
        self.stack = QStackedWidget()
        self.home_page = QWidget()
        self.stack.addWidget(self.home_page)

        # Layout principale
        main = QVBoxLayout(self.home_page)
        main.setContentsMargins(20, 20, 20, 20)
        main.setSpacing(16)

        # Cornice esterna
        frame_border = QFrame()
        frame_border.setStyleSheet(f"border: 3px solid {NEON_SOFT}; border-radius: 10px; background-color: {BG_DARK};")
        frame_layout = QVBoxLayout(frame_border)
        frame_layout.setContentsMargins(10, 10, 10, 10)
        frame_layout.setSpacing(16)

        # === Barra superiore ================================================
        top = QHBoxLayout()
        top.setSpacing(20)

        btn_settings = QPushButton()
        btn_settings.setObjectName("round")
        btn_settings.setIcon(QIcon(str(DIR_ICONE / "icona_impostazioni.png")))
        btn_settings.setIconSize(QSize(36, 36))
        btn_settings.setToolTip("Impostazioni")
        btn_settings.clicked.connect(self.show_settings)
        apply_press_glow(btn_settings)

        self.clock = QLabel("--:--:--")
        self.clock.setObjectName("clock")
        self.clock.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.clock.setFixedHeight(60)
        self.clock.setFont(QFont(self.config["font"], 26, QFont.Weight.Bold))

        btn_exit = QPushButton()
        btn_exit.setObjectName("round")
        btn_exit.setIcon(QIcon(str(DIR_ICONE / "icona_exit.png")))
        btn_exit.setIconSize(QSize(36, 36))
        btn_exit.setToolTip("Chiudi programma")
        btn_exit.clicked.connect(self.close)
        apply_press_glow(btn_exit)

        top.addWidget(btn_settings)
        top.addStretch()
        top.addWidget(self.clock)
        top.addStretch()
        top.addWidget(btn_exit)
        frame_layout.addLayout(top)

        line = QFrame()
        line.setStyleSheet(f"background-color: {NEON_SOFT};")
        line.setFixedHeight(2)
        frame_layout.addWidget(line)

        grid = QGridLayout()
        grid.setHorizontalSpacing(40)
        grid.setVerticalSpacing(40)
        grid.setContentsMargins(30, 30, 30, 30)

        tiles = [
            ("MANUALE", "icona_manuale.png"),
            ("mLRS", "icona_mlrs.png"),
            ("FPV VIDEO", "icona_fpvvideo.png"),
            ("VEIVOLO SU MAPPA", "icona_veivolosumappa.png"),
            ("RADAR AEREI", "icona_radaraerei.png"),
        ]
        positions = [(0,0),(0,1),(0,2),(1,0),(1,1)]

        for (r, c), (label, icon) in zip(positions, tiles):
            tile = TileButton(label, DIR_ICONE / icon, self.config["font"], self.config["font_color"])
            grid.addWidget(tile, r, c)
            if label == "MANUALE":
                tile.button.clicked.connect(self.show_manuale)
            elif label == "mLRS":
                tile.button.clicked.connect(self.show_mlrs)
            elif label == "FPV VIDEO":
                tile.button.clicked.connect(self.show_fpv)
            elif label == "VEIVOLO SU MAPPA":
                tile.button.clicked.connect(self.show_mappa)
            elif label == "RADAR AEREI":
                tile.button.clicked.connect(self.show_radar)

        frame_layout.addLayout(grid)
        main.addWidget(frame_border)

        self._t = QTimer(self)
        self._t.timeout.connect(self._tick_clock)
        self._t.start(1000)
        self._tick_clock()

        self.setCentralWidget(self.stack)
        self.showMaximized()

    def _tick_clock(self):
        self.clock.setText(datetime.now().strftime("%H:%M:%S"))

    def show_settings(self):
        from impostazioni import SettingsPage
        settings_page = SettingsPage(parent=self)
        settings_page.go_home = self.refresh_style_after_settings
        self.stack.addWidget(settings_page)
        self.stack.setCurrentWidget(settings_page)

    def refresh_style_after_settings(self):
        self.config = load_config()
        self.setStyleSheet(generate_qss(self.config["font_color"], self.config["font"]))
        self.clock.setFont(QFont(self.config["font"], 26, QFont.Weight.Bold))
        self.stack.setCurrentWidget(self.home_page)

    def show_manuale(self):
        from manuale import ManualePage
        page = ManualePage(parent=self)
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)

    def show_mlrs(self):
        from mlrs import MlrsPage
        page = MlrsPage(parent=self)
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)

    def show_fpv(self):
        from fpvvideo import FPVPage
        page = FPVPage(parent=self)
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)

    def show_mappa(self):
        from veivolosumappa import MappaPage
        page = MappaPage(parent=self)
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)

    def show_radar(self):
        from radaraerei import RadarPage
        page = RadarPage(parent=self)
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)

    def show_home(self):
        self.stack.setCurrentWidget(self.home_page)


# === MAIN ====================================================================
def main():
    config = load_config()
    app = QApplication(sys.argv)
    app.setFont(QFont(config["font"], 14))
    app.setStyleSheet(generate_qss(config["font_color"], config["font"]))

    # === Inizializzazione sicura di esp_interface ===========================
    from esp_interface import ESPInterface, esp
    global esp
    if esp is None:
        esp = ESPInterface()
        print("[INIT] ESPInterface inizializzato dopo QApplication")

    # ========================================================================
    w = HomeWindow()
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
